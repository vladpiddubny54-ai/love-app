import math
from kivy.app import App
from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle
from kivy.core.text import Label as CoreLabel
from kivy.clock import Clock


class LoveWidget(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.scale = 11
        self.i = 0
        self.draw_background()
        Clock.schedule_interval(self.draw_heart, 0.02)

    def draw_background(self):
        with self.canvas:
            Color(0, 0, 0, 1)
            self.bg = Rectangle(pos=self.pos, size=self.size)

    def on_size(self, *args):
        if hasattr(self, "bg"):
            self.bg.size = self.size

    def draw_heart(self, dt):
        if self.scale > 16:
            Clock.unschedule(self.draw_heart)
            return

        t = self.i * math.tau / 120

        x = 16 * math.sin(t) ** 3
        y = (
            13 * math.cos(t)
            - 5 * math.cos(2 * t)
            - 2 * math.cos(3 * t)
            - math.cos(4 * t)
        )

        # Масштабуємо сердечко під екран телефона
        sx = self.width / 2 + x * self.scale * 0.75
        sy = self.height / 2 + y * self.scale * 0.75

        label = CoreLabel(
            text="I love you",
            font_size=12,
            color=(1, 0.714, 0.757, 1),
        )
        label.refresh()

        with self.canvas:
            Color(1, 0.714, 0.757, 1)
            self.canvas.add(
                Rectangle(
                    texture=label.texture,
                    pos=(sx - label.texture.size[0] / 2,
                         sy - label.texture.size[1] / 2),
                    size=label.texture.size,
                )
            )

        self.i += 1
        if self.i >= 120:
            self.i = 0
            self.scale += 1


class LoveApp(App):
    title = "I love you"

    def build(self):
        return LoveWidget()


if __name__ == "__main__":
    LoveApp().run()
