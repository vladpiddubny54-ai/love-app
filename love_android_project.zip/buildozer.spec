[app]

# Назва застосунку
title = I love you

# Назва пакета
package.name = iloveyou

# Домен
package.domain = org.example

# Папка з main.py
source.dir = .

# Файл запуску
source.include_exts = py,png,jpg,kv,atlas

# Версія
version = 1.0

# Бібліотеки
requirements = python3,kivy

# Орієнтація
orientation = portrait

# Повноекранний режим
fullscreen = 1

# Android
android.api = 35
android.minapi = 21

# Не потрібні дозволи
android.permissions =

[buildozer]

log_level = 2
warn_on_root = 1
